science

Scientiffic soft

This repo contains the bee_path_science package. It contains the scienttific modules used for the bee-path experiments. All the codes are written in standard python, using the following modules:

Numpy 
Scipy 
Pyproj
Shapely


optionally simplekml for mapping

The module is fully documented (but could be improved).

Authors: Oleguer Sagarra <osagarra@ub.edu> and Mario Gutiérrez Roig


Disclaimer: The software is provided as it is, with absolutely NO WARRANTY. If you detect any bugs, please let us know.



### To install #####
just untar the file and then as usual
$> python setup.py install


